# 大号商采购 API

## 接口

生产入口：`POST https://api.lynli.me/api/buy`

请求头：
- `Authorization: Bearer <供应商采购 API Token>`
- `Idempotency-Key: <每次采购请求唯一值>`
- `Content-Type: application/json`

请求体：
```json
{"product_id":"1553958197179793702","count":1}
```

成功响应：
```json
{
  "ok": true,
  "supplier_order_id": "上游订单ID",
  "supplier_order_no": "上游订单号",
  "supplier_status": "已发货",
  "product_id": "1553958197179793702",
  "count": 1,
  "content": "卡密内容",
  "http_status": 200
}
```

由于 Lynli API 现有响应封装会统一使用 HTTP 200，调用方应同时检查 JSON 的 `ok` 和 `http_status` 字段。

## 实现

- 路由模块：`/opt/lynli-api/api_supplier_buy.py`
- 已挂载到现有 `lynli-api.service`，不另起端口。
- 上游采购复用：`/root/fakabot/supplier_client.py` 的 `DahaoshangClient.buy_with_balance()`。
- 上游购买：`POST /api/sysorder/buy`。
- 卡密读取：`POST /api/sysorder/getorder`。
- 只允许上游账户余额付款；不会改用其他付款方式。
- Token 文件：`/root/.config/fakabot/supplier_buy_api_token`，权限 600。
- 幂等状态库：`/root/.config/fakabot/supplier_buy_api.sqlite3`。
- 必须传唯一 `Idempotency-Key`。成功重试返回缓存结果；处理中或结果不确定时拒绝再次采购。
- 上游下单超时不自动重试，避免重复扣款。

## 当前状态

接口代码已部署并通过模拟调用测试：成功结果缓存、相同幂等键重放、参数不匹配拒绝、错误 Token 拒绝均通过；未发起真实采购。

当前 `SUPPLIER_BUY_API_ENABLED=0`，接口暂时关闭。最近只读供应商会话校验时，上游请求返回 HTTP 520（大号商域名与 auth 代理均如此），因此没有启用真实采购。恢复上游 HTTP 访问并通过只读账户校验后，才可将该开关改为 1。

不要将采购 Token 放入浏览器前端代码；只允许网站后端或机器人服务端读取并使用。
