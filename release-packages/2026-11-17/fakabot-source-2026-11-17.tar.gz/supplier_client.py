import os
import requests

class DahaoshangClient:
    def __init__(self, *args, **kwargs):
        self.api_url = "http://167.253.96.220:8001/api/buy"
        self.api_key = os.getenv("SHOP_BUY_API_KEY", "").strip()
        if not self.api_key:
            raise RuntimeError("SHOP_BUY_API_KEY 未配置，请先在服务环境文件中设置")
        self.base_url = "http://167.253.96.220:8001"

    def _headers(self):
        return {"x-api-key": self.api_key}

    def buy_with_balance(self, product_id, quantity=1, model_id=None, email="", expected_price_cny=None):
        headers = self._headers()
        headers["Content-Type"] = "application/json"
        payload = {"product_id": str(product_id), "qty": quantity}
        try:
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=15)
            data = response.json()
            if data.get("success") is True:
                return {
                    "supplier_order_id": str(data.get("order_id")),
                    "supplier_order_no": str(data.get("order_id")),
                    "content": str(data.get("card"))
                }
            raise Exception(f"上游购买失败: {data.get('msg')}")
        except requests.exceptions.RequestException as e:
            raise Exception(f"发卡 API 请求异常: {str(e)}")

    def get_order(self, order_id):
        return {}

    def get_categories(self):
        """Fetch real supplier categories through the 167 proxy."""
        try:
            response = requests.get(
                f"{self.base_url}/api/categories",
                headers=self._headers(),
                timeout=15,
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                rows = data
            elif isinstance(data, dict):
                rows = data.get("Data", [])
                if isinstance(rows, dict):
                    rows = rows.get("Items", [])
            else:
                rows = []
            if not isinstance(rows, list):
                raise RuntimeError("分类接口 Data 不是数组")
            rows = [
                row for row in rows
                if isinstance(row, dict) and str(row.get("ID") or "").strip()
            ]
            if not rows:
                raise RuntimeError("上游分类接口返回 0 条有效分类")
            return rows
        except requests.RequestException as exc:
            raise RuntimeError(f"发卡代理分类接口请求失败: {exc}") from exc
        except ValueError as exc:
            raise RuntimeError("发卡代理分类接口返回非 JSON") from exc

    def get_product_list(self, category_id=None):
        """Fetch products; proxy returns Data as a list, not Data.Items."""
        try:
            url = f"{self.base_url}/api/products"
            params = {"categoryId": str(category_id)} if category_id is not None else {}
            response = requests.get(
                url,
                headers=self._headers(),
                params=params,
                timeout=20,
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                rows = data
            elif isinstance(data, dict):
                if data.get("Code") not in (None, 200, "200"):
                    raise RuntimeError(
                        f"上游商品接口错误: {data.get('Message') or data.get('Code')}"
                    )
                rows = data.get("Data", [])
                if isinstance(rows, dict):
                    rows = rows.get("Items", [])
            else:
                rows = []
            if not isinstance(rows, list):
                raise RuntimeError("商品接口 Data 不是数组")
            return [row for row in rows if isinstance(row, dict)]
        except requests.RequestException as exc:
            raise RuntimeError(f"发卡代理商品接口请求失败: {exc}") from exc
        except ValueError as exc:
            raise RuntimeError("发卡代理商品接口返回非 JSON") from exc

    def __getattr__(self, name):
        def dummy(*args, **kwargs):
            return []
        return dummy
