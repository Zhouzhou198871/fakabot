# Product catalog package. Product rows live in one file per category.
