-- Termux personal-Alipay notification matching; old orders remain untouched.
ALTER TABLE faka_orders ADD COLUMN payment_amount_cny_fen INTEGER;
ALTER TABLE faka_orders ADD COLUMN exchange_rate TEXT NOT NULL DEFAULT '8';
ALTER TABLE faka_orders ADD COLUMN mock_delivery_code TEXT;
ALTER TABLE faka_orders ADD COLUMN mock_delivered_at TEXT;

CREATE INDEX IF NOT EXISTS idx_faka_orders_cny_pending
ON faka_orders(payment_status, payment_amount_cny_fen, created_at);

CREATE TABLE IF NOT EXISTS faka_termux_events (
  event_id TEXT PRIMARY KEY,
  amount_cny_fen INTEGER NOT NULL,
  received_at TEXT NOT NULL,
  matched_order_id TEXT,
  status TEXT NOT NULL DEFAULT 'received',
  payload_hash TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_faka_termux_events_amount_received
ON faka_termux_events(amount_cny_fen, received_at);
