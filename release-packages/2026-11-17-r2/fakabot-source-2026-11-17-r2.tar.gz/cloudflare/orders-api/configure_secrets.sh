#!/usr/bin/env bash
set -euo pipefail
TOKEN_FILE="/root/.config/fakabot/orders_api_tokens.env"
if [[ ! -r "$TOKEN_FILE" ]]; then
  echo "Missing $TOKEN_FILE" >&2
  exit 1
fi
if ! npx wrangler whoami >/dev/null 2>&1; then
  echo "Cloudflare Wrangler is not authenticated. Run: npx wrangler login" >&2
  exit 2
fi
set -a
# shellcheck disable=SC1090
source "$TOKEN_FILE"
set +a
for key in BOT_API_TOKEN PAYMENT_LISTENER_TOKEN PROCUREMENT_EXECUTOR_TOKEN; do
  value="${!key:-}"
  if [[ ${#value} -lt 64 ]]; then
    echo "Invalid or missing $key in $TOKEN_FILE" >&2
    exit 3
  fi
  printf '%s' "$value" | npx wrangler secret put "$key" --name fakabot-orders
done
TERMUX_SECRET_FILE="/root/.config/fakabot/termux_notify_secret"
if [[ ! -s "$TERMUX_SECRET_FILE" ]]; then
  install -d -m 700 /root/.config/fakabot
  umask 077
  openssl rand -hex 32 > "$TERMUX_SECRET_FILE"
fi
chmod 600 "$TERMUX_SECRET_FILE"
printf '%s' "$(cat "$TERMUX_SECRET_FILE")" | npx wrangler secret put TERMUX_NOTIFY_SECRET --name fakabot-orders
echo "Worker API secrets and Termux HMAC secret installed. Procurement remains paused.";
