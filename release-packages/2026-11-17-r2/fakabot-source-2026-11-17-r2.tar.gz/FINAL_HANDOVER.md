# Fakabot 生产交付验收单
日期：2026-11-17
项目目录：`/root/fakabot`

## 当前生产链路
- Telegram 机器人、订单和收款处理：主服务器 `/root/fakabot`。
- 大号商目录与余额采购：167 服务器 `my-shop-api.service`，端口 8001。
- 支付宝网关：167 `pay-gateway.service`，端口 8000，经既有 SSH 隧道 `127.0.0.1:18000` 调用。
- 支付回调：主服务器 loopback `127.0.0.1:8011`，公网 HTTPS 路由 `/webhook/alipay_success`。
- USDT TRC20：主服务器监听器。

## 本次完成
- 退役生产机器人中的 Cloudflare Alipay D1 队列轮询和旧沙箱回调命令。
- 移除未使用的 Cloudflare 目录客户端；机器人目录改由大号商认证 API 提供。
- 实现真实供应商 SKU 预检：商品 ID、上架状态、库存、限购、成本。
- 付款确认后采购前再次预检；167 API 采购请求串行化，向上游只发一次请求，不盲目重试。
- 退役 `fakabot-alipay-notify` Worker；历史源码保留在 archive。
- 完善 README、买家说明、运维说明和供应商 API 说明。

## D1 注意事项
支付宝通知队列不再被生产机器人使用。共享 `fakabot-procurement-db` 保留，因为 Cloudflare storefront、procurement、orders 和 supplier-auth-proxy 等独立 Worker 仍绑定该库；不得直接删除整库。

## 验收
- 167 商品分类接口：28 条；机器人重启后实时目录同步成功：29 个分类（含本地虚拟分类）/ 1,186 个当时在售商品。
- 预检测试：PASS（只读）。
- Mock 采购/发货闭环：PASS；真实采购 0、真实付款 0。
- 回调本机健康检查：PASS；公网未认证回调返回 401。
- Python 编译：PASS。

真实付款和真实采购没有在本轮执行；不以 Mock 测试冒充真实交易验收。

## 固定路径
- 主项目：`/root/fakabot`
- 主服务：`fakabot.service`
- 167 发卡 API：`/root/my_shop_api.py` / `my-shop-api.service`
- 167 支付网关：`/opt/pay-gateway` / `pay-gateway.service`
- 主服务器隧道：`pay-gateway-tunnel.service`

不要搬迁服务或改变既有监听位置。严禁提交 `.env`、Token、API Key、私钥、供应商账号凭据、订单数据或交付卡密。
