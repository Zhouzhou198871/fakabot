# Retired: Cloudflare Alipay notification queue

Retired on 2026-11-17. This Worker used the shared `fakabot-procurement-db` D1 database and the `alipay_notifications` queue. The production Telegram bot no longer polls this queue or sends payment callbacks to this Worker.

The active checkout flow is:

1. Telegram bot creates a 60-second order through the existing 167 payment gateway.
2. The gateway calls the self-hosted callback `https://api.lynli.me/webhook/alipay_success`.
3. The main server validates the gateway authentication token, exact gateway/business order IDs, amount, pending state and expiry.
4. The main server performs supplier procurement and Telegram delivery.

Do not redeploy this Worker. The source is retained only for historical reference. The shared D1 database is not deleted because other Cloudflare Workers still bind to it for storefront/catalog/inventory and legacy order data.
