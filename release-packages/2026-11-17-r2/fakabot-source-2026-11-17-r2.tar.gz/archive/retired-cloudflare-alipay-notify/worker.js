const cors={'access-control-allow-origin':'*','access-control-allow-methods':'GET, POST, OPTIONS','access-control-allow-headers':'Content-Type, Authorization','access-control-max-age':'86400'};
const json=(v,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{...cors,'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
const text=(v,s=200)=>new Response(v,{status:s,headers:{...cors,'content-type':'text/plain; charset=utf-8','cache-control':'no-store'}});
const now=()=>new Date().toISOString();
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function pemBytes(pem){const b64=String(pem||'').replace(/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----|\s/g,'');const bin=atob(b64);return Uint8Array.from(bin,c=>c.charCodeAt(0));}
function canonical(p){return Object.keys(p).filter(k=>k!=='sign'&&k!=='sign_type'&&p[k]!==''&&p[k]!=null).sort().map(k=>k+'='+p[k]).join('&');}
async function verify(p,env){if(!env.ALIPAY_APP_ID||!env.ALIPAY_PUBLIC_KEY||!env.ALIPAY_SELLER_ID)return false;if(String(p.sign_type||'')!=='RSA2'||String(p.app_id||'')!==env.ALIPAY_APP_ID||String(p.seller_id||'')!==env.ALIPAY_SELLER_ID)return false;try{const key=await crypto.subtle.importKey('spki',pemBytes(env.ALIPAY_PUBLIC_KEY),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);const sig=Uint8Array.from(atob(String(p.sign||'')),c=>c.charCodeAt(0));return await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,sig,new TextEncoder().encode(canonical(p)));}catch{return false;}}
async function verifyFundOrderChanged(p,env){if(!env.ALIPAY_APP_ID||!env.ALIPAY_PUBLIC_KEY)return false;if(String(p.sign_type||'')!=='RSA2'||String(p.app_id||'')!==env.ALIPAY_APP_ID||String(p.msg_method||'')!=='alipay.fund.trans.order.changed'||!p.biz_content)return false;try{const key=await crypto.subtle.importKey('spki',pemBytes(env.ALIPAY_PUBLIC_KEY),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);const sig=Uint8Array.from(atob(String(p.sign||'')),c=>c.charCodeAt(0));return await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,sig,new TextEncoder().encode(canonical(p)));}catch{return false;}}
async function mockSignatureValid(order,amount,expires,sig,env){if(!env.ALIPAY_NOTIFY_TOKEN)return false;try{const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.ALIPAY_NOTIFY_TOKEN),{name:'HMAC',hash:'SHA-256'},false,['sign']);const data=new TextEncoder().encode(`${order}|${amount}|${expires}`);const mac=new Uint8Array(await crypto.subtle.sign('HMAC',key,data));const hex=[...mac].map(x=>x.toString(16).padStart(2,'0')).join('');return hex===String(sig||'').toLowerCase();}catch{return false;}}
async function waitUntilProcessed(env,notifyId,tradeNo){for(let i=0;i<36;i++){const row=await env.DB.prepare('SELECT processed_at FROM alipay_notifications WHERE notify_id=? OR trade_no=? LIMIT 1').bind(notifyId,tradeNo).first();if(row&&row.processed_at)return true;await sleep(500);}return false;}
async function enqueue(env,notifyId,tradeNo,order,payload){const event=crypto.randomUUID();await env.DB.prepare('INSERT OR IGNORE INTO alipay_notifications (event_id,notify_id,trade_no,out_trade_no,payload_json,received_at) VALUES (?,?,?,?,?,?)').bind(event,notifyId,tradeNo,order,JSON.stringify(payload),now()).run();}
function md5hex(input){
 const bytes=Array.from(new TextEncoder().encode(String(input)));const bitLength=bytes.length*8;bytes.push(0x80);while(bytes.length%64!==56)bytes.push(0);for(let i=0;i<8;i++)bytes.push(Math.floor(bitLength/Math.pow(2,8*i))&255);
 const shifts=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21];const k=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*4294967296)>>>0);let a0=0x67452301,b0=0xefcdab89,c0=0x98badcfe,d0=0x10325476;
 for(let off=0;off<bytes.length;off+=64){const m=[];for(let j=0;j<16;j++)m[j]=(bytes[off+j*4]|(bytes[off+j*4+1]<<8)|(bytes[off+j*4+2]<<16)|(bytes[off+j*4+3]<<24))>>>0;let a=a0,b=b0,c=c0,d=d0;
  for(let i=0;i<64;i++){let f,g,sh;if(i<16){f=(b&c)|(~b&d);g=i;sh=shifts[i%4];}else if(i<32){f=(d&b)|(~d&c);g=(5*i+1)%16;sh=shifts[4+i%4];}else if(i<48){f=b^c^d;g=(3*i+5)%16;sh=shifts[8+i%4];}else{f=c^(b|~d);g=(7*i)%16;sh=shifts[12+i%4];}const sum=(a+f+k[i]+m[g])>>>0;const rot=((sum<<sh)|(sum>>>(32-sh)))>>>0;a=d;d=c;c=b;b=(b+rot)>>>0;}
  a0=(a0+a)>>>0;b0=(b0+b)>>>0;c0=(c0+c)>>>0;d0=(d0+d)>>>0;
 }
 return [a0,b0,c0,d0].map(x=>[x&255,(x>>>8)&255,(x>>>16)&255,(x>>>24)&255].map(v=>v.toString(16).padStart(2,'0')).join('')).join('');
}
async function vmqPayload(req,url,env){
 if(!env.VMQ_NOTIFY_TOKEN)return null;let p={},protocol='szvone_appPush';
 if(req.method==='GET'){for(const [k,v] of url.searchParams)p[k]=v;}
 else {const ct=(req.headers.get('content-type')||'').toLowerCase();try{if(ct.includes('application/json')){p=await req.json();protocol='vmq_json';}else{const f=await req.formData();for(const [k,v] of f.entries())if(typeof v==='string')p[k]=v;}}catch{return null;}}
 const payId=String(p.payId||p.payid||'').trim(),price=String(p.price||'').trim(),sign=String(p.sign||'').trim(),type=String(p.type??(protocol==='vmq_json'?'2':'')).trim(),t=String(p.t||'').trim();
 if(!/^\d+(?:\.\d{1,2})?$/.test(price)||!sign||type!=='2')return null;
 let valid=false;
 if(protocol==='szvone_appPush'){
  if(!/^\d{13}$/.test(t)||Math.abs(Date.now()-Number(t))>50000)return null;
  valid=sign.toLowerCase()===md5hex(type+price+t+env.VMQ_NOTIFY_TOKEN);
 }else{
  valid=sign.toLowerCase()===md5hex(price+env.VMQ_NOTIFY_TOKEN)||sign.toLowerCase()===md5hex(payId+price+env.VMQ_NOTIFY_TOKEN);
  if(!valid&&t&&/^\d{13}$/.test(t)&&Math.abs(Date.now()-Number(t))<=50000)valid=sign.toLowerCase()===md5hex(type+price+t+env.VMQ_NOTIFY_TOKEN);
  if(!payId)return null;
 }
 if(!valid)return null;
 const amount=Number(price).toFixed(2),stamp=t||String(Date.now()),key=`vmq:${protocol}:${type}:${payId||stamp}:${amount}`;
 return {event_type:'vmq_android_push',vmq_protocol:protocol,payId,out_trade_no:payId,total_amount:amount,price,vmq_type:type,vmq_timestamp:stamp,vmq_signature:sign,trade_status:'VMQ_SUCCESS',trade_no:key,notify_id:key};
}
async function vmqHeartbeat(req,url,env){
 if(!env.VMQ_NOTIFY_TOKEN)return false;let p={};if(req.method==='GET'){for(const [k,v] of url.searchParams)p[k]=v;}else{try{const f=await req.formData();for(const [k,v] of f.entries())if(typeof v==='string')p[k]=v;}catch{return false;}}
 const t=String(p.t||''),sign=String(p.sign||'').toLowerCase();if(!/^\d{13}$/.test(t)||Math.abs(Date.now()-Number(t))>50000)return false;return sign===md5hex(t+env.VMQ_NOTIFY_TOKEN);
}
function mockPage(url){const fields=['order_id','total_amount','expires_at_ms','sig'];const hidden=fields.map(k=>`<input type="hidden" name="${k}" value="${String(url.searchParams.get(k)||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}">`).join('');return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沙箱模拟支付</title><body style="font-family:system-ui;max-width:520px;margin:12vh auto;padding:24px;color:#17202a"><h2>🧪 支付宝沙箱模拟页</h2><p>这是本地模拟流程，不会连接支付宝，不会扣款，也不会触发采购或发货。</p><p>订单：<b>${url.searchParams.get('order_id')}</b></p><p>测试金额：<b>¥${url.searchParams.get('total_amount')}</b></p><form method="POST" action="/mock/confirm">${hidden}<button style="width:100%;padding:14px;border:0;border-radius:10px;background:#1677ff;color:white;font-size:16px">模拟支付成功</button></form><p style="color:#667085;font-size:13px">仅用于验证机器人订单通知链路。</p></body></html>`;}
export default {async fetch(req,env){const u=new URL(req.url);
if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
if(u.pathname==='/health'&&req.method==='GET')return json({ok:true,service:'fakabot-alipay-notify',database:'bound',credentials_configured:Boolean(env.ALIPAY_APP_ID&&env.ALIPAY_PUBLIC_KEY&&env.ALIPAY_SELLER_ID),token_configured:Boolean(env.ALIPAY_NOTIFY_TOKEN),vmq_token_configured:Boolean(env.VMQ_NOTIFY_TOKEN)});
if(u.pathname==='/mock'&&req.method==='GET'){const order=String(u.searchParams.get('order_id')||''),amount=String(u.searchParams.get('total_amount')||''),expires=String(u.searchParams.get('expires_at_ms')||''),sig=String(u.searchParams.get('sig')||'');if(!/^AL[A-F0-9]{12}$/.test(order)||!/^\d+\.\d{2}$/.test(amount)||!/^\d+$/.test(expires)||Number(expires)<Date.now()||!await mockSignatureValid(order,amount,expires,sig,env))return text('invalid_or_expired_mock_link',400);return new Response(mockPage(u),{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});}
if(u.pathname==='/mock/confirm'&&req.method==='POST'){if(!env.ALIPAY_NOTIFY_TOKEN)return text('configuration_error',503);const f=await req.formData(),order=String(f.get('order_id')||''),amount=String(f.get('total_amount')||''),expires=String(f.get('expires_at_ms')||''),sig=String(f.get('sig')||'');if(!/^AL[A-F0-9]{12}$/.test(order)||!/^\d+\.\d{2}$/.test(amount)||!/^\d+$/.test(expires)||Number(expires)<Date.now()||!await mockSignatureValid(order,amount,expires,sig,env))return text('failure',400);const tradeNo='MOCK-'+order,notifyId='MOCK-'+order;const payload={mock:'1',out_trade_no:order,total_amount:amount,trade_status:'MOCK_SUCCESS',expires_at_ms:expires,mock_signature:sig,trade_no:tradeNo,notify_id:notifyId};try{await enqueue(env,notifyId,tradeNo,order,payload);return new Response('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>模拟请求已提交</title><h2>模拟支付请求已提交</h2><p>请返回 Telegram 查看机器人测试结果。不会发生真实扣款或发货。</p>',{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}});}catch{return text('failure',503);}}
if(u.pathname==='/vmq/notify'&&req.method==='POST'){
 if(!env.MACRODROID_NOTIFY_TOKEN)return json({code:-1,msg:'configuration_error'},503);
 const raw=await req.clone().text();
 // Diagnostic log deliberately redacts the shared secret before writing request data to logs.
 let p;try{p=JSON.parse(raw);}catch{console.log(JSON.stringify({event:'macrodroid_request',content_type:req.headers.get('content-type')||'',body:raw.slice(0,5000),parse_error:true}));return json({code:-1,msg:'invalid_json'},400);}
 const safeBody={...p};if(Object.prototype.hasOwnProperty.call(safeBody,'sign'))safeBody.sign='[REDACTED]';
 console.log(JSON.stringify({event:'macrodroid_request',content_type:req.headers.get('content-type')||'',body:JSON.stringify(safeBody).slice(0,5000),utf8_bytes:new TextEncoder().encode(raw).length}));
 if(!p||typeof p!=='object'||Array.isArray(p))return json({code:-1,msg:'invalid_payload'},400);
 if(String(p.sign||'').trim()!==env.MACRODROID_NOTIFY_TOKEN)return json({code:-1,msg:'unauthorized'},401);
 const notice=String(p.text||'').trim(),timeValue=p.time,testMode=p.test_mode===true;
 if(!notice||notice.length>5000||timeValue==null||String(timeValue).length>80)return json({code:-1,msg:'invalid_text_or_time'},400);
 if(!testMode){
  let sentAt;
  if(typeof timeValue==='number'||/^\d{10,13}$/.test(String(timeValue))){const n=Number(timeValue);sentAt=String(timeValue).length===10?n*1000:n;}
  else sentAt=Date.parse(String(timeValue));
  if(!Number.isFinite(sentAt)||Math.abs(Date.now()-sentAt)>300000)return json({code:-1,msg:'time_expired_or_invalid'},400);
 }
 // Test-mode events are explicitly tagged and cannot enter the payment-matching branch.
 const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(timeValue)+'\n'+notice+'\n'+String(testMode))));
 const fingerprint=[...digest].map(x=>x.toString(16).padStart(2,'0')).join('');
 const key='macro:'+fingerprint;
 const payload={event_type:testMode?'macrodroid_alipay_test_notice':'macrodroid_alipay_notice',test_mode:testMode,text:notice,time:String(timeValue),notify_id:key,trade_no:key,trade_status:testMode?'TEST_ONLY':'NOTICE_RECEIVED'};
 try{await enqueue(env,key,key,'',payload);return json({code:1,msg:'success',test_mode:testMode,event_id:key});}
 catch{return json({code:-1,msg:'queue_write_failed'},503);}
}
if((u.pathname==='/vmq/notify'||u.pathname==='/appPush')&&(req.method==='POST'||req.method==='GET')){const legacy=u.pathname==='/appPush',p=await vmqPayload(req,u,env);if(!p)return legacy?json({code:-1,msg:'签名或参数错误'}):text('failure',400);try{await enqueue(env,p.notify_id,p.trade_no,p.payId,p);return legacy?json({code:1,msg:'success'}):text('success');}catch{return legacy?json({code:-1,msg:'队列写入失败'},503):text('failure',503);}}
if(u.pathname==='/'||(u.pathname==='/appHeart'&&(req.method==='GET'||req.method==='POST')))return json({code:1,msg:'success'});
if(u.pathname==='/getState'&&req.method==='GET'){if(!await vmqHeartbeat(req,u,env))return json({code:-1,msg:'签名或时间戳错误'});const t=String(u.searchParams.get('t')||'');return json({code:1,msg:'成功',data:{state:'1',lastheart:t,lastpay:''}});}
if(u.pathname==='/notify'&&req.method==='POST'){const form=await req.formData(),p={};for(const [k,v] of form.entries())if(typeof v==='string')p[k]=v;if(String(p.msg_method||'')==='alipay.fund.trans.order.changed'){if(!await verifyFundOrderChanged(p,env))return text('failure',400);let biz;try{biz=JSON.parse(String(p.biz_content||''));if(!biz||typeof biz!=='object'||Array.isArray(biz))throw new Error('invalid_biz_content');}catch{return text('failure',400);}const trade=String(biz.pay_fund_order_id||biz.order_id||'');if(!trade)return text('failure',400);const notify=String(p.notify_id||('fund:'+trade));const payload={event_type:'alipay_fund_order_changed',outer:p,biz_content:biz};try{await enqueue(env,notify,trade,String(biz.out_biz_no||''),payload);console.log(JSON.stringify({event:'alipay_fund_order_changed_received',notify_id:notify,amount:biz.trans_amount||'',alipay_trade_no:trade,remark:biz.remark||biz.summary||'',transaction_time:biz.pay_date||'',status:biz.status||''}));return text('success');}catch{return text('failure',503);}}if(!env.ALIPAY_APP_ID||!env.ALIPAY_PUBLIC_KEY||!env.ALIPAY_SELLER_ID)return text('failure',503);if(!await verify(p,env))return text('failure',400);if(String(p.trade_status||'')!=='TRADE_SUCCESS')return text('failure',400);const trade=String(p.trade_no||''),order=String(p.out_trade_no||''),amount=String(p.total_amount||'');if(!trade||!order||!/^\d+\.\d{2}$/.test(amount))return text('failure',400);const notify=String(p.notify_id||('trade:'+trade+':'+p.trade_status));try{await enqueue(env,notify,trade,order,p);const done=await waitUntilProcessed(env,notify,trade);return done?text('success'):text('failure',503);}catch{return text('failure',503);}}
if(u.pathname==='/internal/events'&&req.method==='GET'){if(req.headers.get('cf-connecting-ip')!=='167.253.96.220'&&![env.MACRODROID_NOTIFY_TOKEN,env.ALIPAY_NOTIFY_TOKEN].filter(Boolean).some(t=>req.headers.get('Authorization')==='Bearer '+t))return json({ok:false,error:'unauthorized'},401);const rows=await env.DB.prepare('SELECT event_id,payload_json,received_at FROM alipay_notifications WHERE processed_at IS NULL ORDER BY received_at LIMIT 30').all();return json({ok:true,items:(rows.results||[]).map(x=>({event_id:x.event_id,params:JSON.parse(x.payload_json),received_at:x.received_at}))});}
const ack=u.pathname.match(/^\/internal\/events\/([a-f0-9-]{36})\/ack$/i);if(ack&&req.method==='POST'){if(req.headers.get('cf-connecting-ip')!=='167.253.96.220'&&![env.MACRODROID_NOTIFY_TOKEN,env.ALIPAY_NOTIFY_TOKEN].filter(Boolean).some(t=>req.headers.get('Authorization')==='Bearer '+t))return json({ok:false,error:'unauthorized'},401);try{const result=await env.DB.prepare('UPDATE alipay_notifications SET processed_at = ? WHERE event_id = ? AND processed_at IS NULL').bind(new Date().toISOString(),ack[1]).run();console.log(JSON.stringify({event:'queue_ack',event_id:ack[1],changes:result.meta?.changes??null}));return json({ok:true,changes:result.meta?.changes??0});}catch(e){console.error(JSON.stringify({event:'queue_ack_failed',event_id:ack[1],error:String(e?.stack||e)}));return json({ok:false,error:'ack_failed'},500);}}
return json({ok:false,error:'not_found'},404);}};