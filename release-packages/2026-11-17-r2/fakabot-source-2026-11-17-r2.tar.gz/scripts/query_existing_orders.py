#!/usr/bin/env python3
# Read-only retrieval of existing supplier orders. This script never calls /buy.
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from supplier_client import DahaoshangClient, SupplierError

ORDER_IDS = ["1571900057475641344", "1571900005541769216"]
try:
    client = DahaoshangClient()
except Exception as exc:
    print(json.dumps({"stage":"session_init", "error_type":type(exc).__name__, "orders":[]}, ensure_ascii=False))
    raise SystemExit(2)
results=[]
failed=False
for oid in ORDER_IDS:
    try:
        result=client.get_order(oid)
        results.append({"order_id":oid,"status":"retrieved","supplier_status":result.get("supplier_status"),"Content":result.get("content")})
    except Exception as exc:
        failed=True
        # Keep credentials/tokens and upstream response bodies out of diagnostic output.
        detail=str(exc)
        results.append({"order_id":oid,"status":"lookup_failed","error_type":type(exc).__name__,"error":detail[:220]})
print(json.dumps({"purchase_requests_sent":0,"orders":results}, ensure_ascii=False, indent=2))
raise SystemExit(1 if failed else 0)
