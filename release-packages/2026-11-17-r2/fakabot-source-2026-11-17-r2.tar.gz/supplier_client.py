import os
import requests

class DahaoshangClient:
    def __init__(self, *args, **kwargs):
        self.api_url = "http://167.253.96.220:8001/api/buy"
        self.api_key = os.getenv("SHOP_BUY_API_KEY", "").strip()
        if not self.api_key:
            raise RuntimeError("SHOP_BUY_API_KEY 未配置，请先在服务环境文件中设置")
        self.base_url = "http://167.253.96.220:8001"

    def _headers(self):
        return {"x-api-key": self.api_key}

    def preflight_purchase(self, product_id, expected_price_cny, quantity=1, model_id=None, email=""):
        """Verify the exact live supplier SKU, sale state, stock and CNY price; never places an order."""
        from decimal import Decimal, InvalidOperation
        product_id = str(product_id or "").strip()
        quantity = int(quantity or 1)
        if not product_id or quantity < 1:
            raise RuntimeError("商品编号或购买数量无效")
        rows = self.get_product_list("0")
        match = next((row for row in rows if str(row.get("ID") or row.get("LinkId") or "").strip() == product_id), None)
        if not match:
            raise RuntimeError("大号商实时商品列表中不存在该商品")
        if match.get("IsOnSale") is not True:
            raise RuntimeError("该商品已下架或暂停销售")
        try:
            stock = int(match.get("InStock") or 0)
            live_price = Decimal(str(match.get("Price"))).quantize(Decimal("0.01"))
            expected_price = Decimal(str(expected_price_cny)).quantize(Decimal("0.01"))
            min_buy = int(match.get("MinBuy") or 1)
            max_buy = int(match.get("MaxBuy") or 0)
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise RuntimeError("大号商商品库存或价格字段无效") from exc
        if stock < quantity:
            raise RuntimeError("大号商实时库存不足")
        if live_price != expected_price:
            raise RuntimeError("大号商实时成本已变化，停止收款以避免价格差异")
        if quantity < max(1, min_buy) or (max_buy > 0 and quantity > max_buy):
            raise RuntimeError("购买数量不符合上游商品限购规则")
        return {
            "supplier_verified": True,
            "procurement_ready": True,
            "supplier_product_id": product_id,
            "supplier_price_cny": format(live_price, ".2f"),
            "supplier_stock": stock,
            "supplier_quantity": quantity,
            "supplier_category_id": str(match.get("CategoryId") or ""),
            "supplier_url": "https://dahaoshang.com/#/product/" + product_id,
        }

    def buy_with_balance(self, product_id, quantity=1, model_id=None, email="", expected_price_cny=None):
        """Recheck the live SKU immediately before a single upstream purchase request."""
        self.preflight_purchase(product_id, expected_price_cny, quantity, model_id=model_id, email=email)
        headers = self._headers()
        headers["Content-Type"] = "application/json"
        payload = {"product_id": str(product_id), "qty": int(quantity)}
        try:
            # Never automatically retry a purchase POST: a timeout can occur after
            # the supplier has accepted and charged the order.
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=20)
            response.raise_for_status()
            data = response.json()
            if data.get("success") is True:
                order_id = str(data.get("order_id") or "").strip()
                card = str(data.get("card") or "").strip()
                if not order_id or not card:
                    raise RuntimeError("上游返回成功但缺少订单号或交付内容，需人工核对")
                return {
                    "supplier_order_id": order_id,
                    "supplier_order_no": order_id,
                    "content": card,
                }
            raise RuntimeError(f"上游购买失败: {data.get('msg') or 'unknown_error'}")
        except requests.exceptions.RequestException as exc:
            raise RuntimeError(f"发卡 API 请求异常，结果可能需要人工核对: {type(exc).__name__}") from exc

    def get_order(self, order_id):
        return {}

    def get_categories(self):
        """Fetch real supplier categories through the 167 proxy."""
        try:
            response = requests.get(
                f"{self.base_url}/api/categories",
                headers=self._headers(),
                timeout=15,
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                rows = data
            elif isinstance(data, dict):
                rows = data.get("Data", [])
                if isinstance(rows, dict):
                    rows = rows.get("Items", [])
            else:
                rows = []
            if not isinstance(rows, list):
                raise RuntimeError("分类接口 Data 不是数组")
            rows = [
                row for row in rows
                if isinstance(row, dict) and str(row.get("ID") or "").strip()
            ]
            if not rows:
                raise RuntimeError("上游分类接口返回 0 条有效分类")
            return rows
        except requests.RequestException as exc:
            raise RuntimeError(f"发卡代理分类接口请求失败: {exc}") from exc
        except ValueError as exc:
            raise RuntimeError("发卡代理分类接口返回非 JSON") from exc

    def get_product_list(self, category_id=None):
        """Fetch products; proxy returns Data as a list, not Data.Items."""
        try:
            url = f"{self.base_url}/api/products"
            params = {"categoryId": str(category_id)} if category_id is not None else {}
            response = requests.get(
                url,
                headers=self._headers(),
                params=params,
                timeout=20,
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                rows = data
            elif isinstance(data, dict):
                if data.get("Code") not in (None, 200, "200"):
                    raise RuntimeError(
                        f"上游商品接口错误: {data.get('Message') or data.get('Code')}"
                    )
                rows = data.get("Data", [])
                if isinstance(rows, dict):
                    rows = rows.get("Items", [])
            else:
                rows = []
            if not isinstance(rows, list):
                raise RuntimeError("商品接口 Data 不是数组")
            return [row for row in rows if isinstance(row, dict)]
        except requests.RequestException as exc:
            raise RuntimeError(f"发卡代理商品接口请求失败: {exc}") from exc
        except ValueError as exc:
            raise RuntimeError("发卡代理商品接口返回非 JSON") from exc

