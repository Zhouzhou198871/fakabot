# 生产交付记录（2026-11-17）

## 本次变更

- 生产机器人移除 Cloudflare Alipay D1 轮询线程，不再访问 `/internal/events` 或 `/ack`。
- 移除旧 `/alipay_test` 线上沙箱回调命令。
- 清理主服务器 `.env` 中旧 Worker URL 配置。
- 移除未使用的 Cloudflare 目录客户端；机器人商品目录统一从 167 大号商 API 读取。
- 退役 `fakabot-alipay-notify` Worker；源码保留在 `archive/retired-cloudflare-alipay-notify/`。
- 修复供应商客户端缺失 `preflight_purchase()` 的问题：现在付款前核对商品 ID、在售状态、库存、限购及实时成本。
- 供应商采购前再次执行只读预检；主机器人采购 POST 只调用一次。167 API 端增加采购串行锁，且对上游采购只发起一次请求，不自动重试不确定结果。
- 新增 README、运维、供应商 API 和买家购买说明。

## 当前部署拓扑（未搬迁）

- 主服务器 `/root/fakabot`：`fakabot.service`，订单/机器人/支付回调/USDT 监听/采购编排。
- 167 `167.253.96.220:8001`：`my-shop-api.service`，大号商目录与采购 API。
- 167 `127.0.0.1:8000`：`pay-gateway.service`。
- 主服务器 `127.0.0.1:18000`：现有 SSH 隧道。
- 主服务器 `127.0.0.1:8011`：自有支付网关回调接收端。

## D1 边界

- 生产 Telegram 机器人已不再依赖支付宝通知 D1 队列。
- `fakabot-alipay-notify` Worker 已退役；`alipay_notifications` 旧表保留历史数据，不再由生产机器人访问。
- 不删除共享 `fakabot-procurement-db`：`fakabot-storefront`、`fakabot-procurement`、`fakabot-orders` 和 `supplier-auth-proxy` 仍绑定该数据库。整库删除会影响这些独立服务。

## 验收结果

- 167 `/health`：HTTP 200。
- 167 `/api/categories`：HTTP 200，28 条分类。
- 167 `/api/products`：HTTP 200；服务重启后机器人成功同步 1,186 条当时在售目录商品（上游库存会动态变化）。
- 机器人目录刷新：29 个分类（含本地虚拟分类）、1,367 个商品、0 个孤立商品。
- 实时商品预检：PASS（只读）。
- Mock 付款到采购/发货闭环：PASS；`/api/buy` POST 被 Mock 拦截一次，真实采购 0，真实付款 0。
- 主服务器本地回调 `/health`：正常。
- 公网回调无认证请求：HTTP 401，确认已到达鉴权入口。
- Python 编译检查：PASS。

## 尚未进行的测试

未使用真实资金或真实供应商余额执行生产订单；因此本次不宣称完成真实付款/真实采购验收。生产付款链路按现有配置启用，第一次真实客户订单仍应由后台密切观察回调、采购响应和 Telegram 发货结果。

## 配置安全

`.env`、Token、API Key、供应商登录凭据、私钥、订单数据库和交付内容均未加入源码仓库。
