# 生产运维说明（2026-11-17）

## 当前生产链路

- 主服务器 `/root/fakabot`：Telegram 机器人、订单归档、支付确认、采购编排、发货通知。
- 167 服务器 `167.253.96.220:8001`：`my-shop-api.service`，提供大号商分类、商品读取和余额采购 API。
- 167 服务器 `127.0.0.1:8000`：`pay-gateway.service`，创建支付宝短时订单。
- 主服务器 `127.0.0.1:18000`：现有 SSH 隧道，转发到 167 的 `127.0.0.1:8000`。
- 主服务器 `127.0.0.1:8011`：自有支付回调接收端，仅监听 loopback，由现有 HTTPS 路由转发到 `/webhook/alipay_success`。
- 主服务器 TRC20 监听器：负责链上 USDT 交易验证。

## 订单购买流程

1. 机器人从 167 `/api/categories` 和 `/api/products` 获取实时目录。
2. 收款前调用 `preflight_purchase`，核对商品 ID、在售状态、库存、限购和实时成本；不一致时拒绝创建支付订单。
3. 支付宝通过 167 网关创建 60 秒订单，网关向 `https://api.lynli.me/webhook/alipay_success` 发送已认证回调。
4. 主服务器核对网关订单号、本店订单号、金额、待支付状态和有效期，再归档付款状态。
5. 付款确认后再次只读核验上游商品，再调用 167 `/api/buy` 一次；保存卡密并向用户私聊发货。
6. 采购响应不确定时进入人工核对状态，不自动重复扣上游余额。

## 支付宝 D1 队列退役

- 已从生产机器人移除 `alipay_event_poll_loop`，不再访问 Worker `/internal/events` 或 `/ack`。
- 已移除旧 `/alipay_test` 沙箱回调命令及其线上 Mock 页面依赖。
- `.env` 不再配置 `ALIPAY_NOTIFY_API_URL`、`ALIPAY_NOTIFY_URL`、`ALIPAY_MOCK_BASE_URL`。
- `fakabot-alipay-notify` Worker 已退役，源代码仅保存在 `archive/retired-cloudflare-alipay-notify/`，禁止重新部署。
- D1 中 `alipay_notifications` 表只属于旧通知 Worker；现存记录保留作历史，不再被生产机器人读取或写入。

**注意：没有删除整个 `fakabot-procurement-db`。** Cloudflare `fakabot-storefront`、`fakabot-procurement`、`fakabot-orders`、`supplier-auth-proxy` 仍绑定同一个 D1 数据库，且数据库还含商品快照、库存和其他订单表。删除整个数据库会破坏这些独立服务。机器人当前下单/采购/收款主链路不依赖这些 D1 表。

## 健康检查

```bash
systemctl is-active fakabot.service
systemctl is-active pay-gateway-tunnel.service
curl -fsS http://127.0.0.1:18000/health
curl -fsS http://127.0.0.1:8011/health
curl -fsS https://api.lynli.me/webhook/alipay_success -X POST -H 'Content-Type: application/json' --data '{}'
```

最后一条未提供认证头时预期返回 HTTP 401；这只验证请求到达认证入口，不代表真实支付测试。

查看日志：

```bash
journalctl -u fakabot.service -n 100 --no-pager
journalctl -u pay-gateway-tunnel.service -n 50 --no-pager
```

## 安全测试边界

- 商品目录和付款前预检可以使用真实只读 API。
- 采购闭环测试必须 Mock `/api/buy` POST、使用内存订单；不能消耗真实供应商余额。
- 不得用真实付款、真实采购或伪造已付款状态来测试生产订单。
- 采购超时或结果不确定时禁止自动重试；先按供应商订单记录人工核对。
- 不得把 `.env`、Token、API Key、私钥、供应商会话、数据库、订单或交付卡密提交到 GitHub。

## 固定部署位置

- 主服务器项目：`/root/fakabot`
- 主机器人：`fakabot.service`
- 167 发卡 API：`/root/my_shop_api.py` / `my-shop-api.service` / `8001`
- 167 支付网关：`/opt/pay-gateway` / `pay-gateway.service` / `127.0.0.1:8000`
- 主服务器 SSH 隧道：`pay-gateway-tunnel.service` / `127.0.0.1:18000`

不要搬迁服务或改变既有监听位置。
