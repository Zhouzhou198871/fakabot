# 大号商采购 API（当前生产接入）

## 运行位置

- 服务器：167（`167.253.96.220`）
- 服务：`my-shop-api.service`
- 源文件：`/root/my_shop_api.py`
- 监听：`0.0.0.0:8001`
- 主机器人客户端：`/root/fakabot/supplier_client.py`

## 只读接口

请求头使用 `x-api-key`，密钥只保存在主服务器 `/root/fakabot/.env` 中的 `SHOP_BUY_API_KEY`，不可写入前端或仓库。

- `GET http://167.253.96.220:8001/health`
- `GET http://167.253.96.220:8001/api/categories`
- `GET http://167.253.96.220:8001/api/products?categoryId=0`

商品目录由大号商实时接口返回。机器人定时刷新本地快照；付款前还会按商品 ID 重新查询实时商品，核对在售、库存、限购和成本。

## 采购接口

`POST http://167.253.96.220:8001/api/buy`

请求头：

```text
x-api-key: <SHOP_BUY_API_KEY>
Content-Type: application/json
```

请求体：

```json
{"product_id":"大号商商品ID","qty":1}
```

成功响应由 167 API 返回 `success=true`、`order_id` 和 `card`。机器人必须同时检查订单号和卡密非空，才会将订单标记为已交付。

## 生产安全逻辑

- `preflight_purchase()` 是只读操作，不下单、不扣余额。
- `buy_with_balance()` 在采购前再次执行实时预检。
- 机器人付款处理器只调用一次 `/api/buy`；167 API 内部用锁串行化采购，并且对大号商 `/api/sysorder/buy` 只发送一次请求，不因超时或非成功响应盲目重试。网络/交付结果不确定时转人工核对。
- 成功卡密先保存到订单归档，再向用户私聊发送；通知失败会保留补发状态。
- 上游采购异常进入人工核对，不允许盲目重复购买。

## 安全测试

当前验收使用真实只读目录 API，并通过 Mock 拦截 `/api/buy` POST，验证订单保存和 Telegram 发货内容；未消耗真实供应商余额、未创建真实上游订单、未发生真实付款。

不要在 GitHub、聊天或前端代码中保存 `SHOP_BUY_API_KEY`、供应商账号密码或其他密钥。

## 167 服务器源代码

线上 `/root/my_shop_api.py` 保留在 167 固定目录。该文件包含上游登录认证材料，不应复制进 GitHub 仓库或公开归档；仅提交不含凭据的主机器人客户端、接口契约和运维说明。
